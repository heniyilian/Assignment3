import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class ProfessorList2014301060003 {
	private String indexURL;
	private File index;
	private ArrayList<String> urlList;
	private ArrayList<Thread> threads;
	private ArrayList<File> htmls;
	private ArrayList<Professor2014301060003> professors;
	private int amount;
	
	public ProfessorList2014301060003() {
		indexURL = "http://www.wpi.edu/academics/cs/research-interests.html";
		index = new File("index.html");
		urlList = new ArrayList<String>();
		threads = new ArrayList<Thread>();
		htmls = new ArrayList<File>();
		professors = new ArrayList<Professor2014301060003>();
		HttpRequest hr =HttpRequest.get(indexURL);
		hr.receive(index);
		//get url list
		try {
			Document doc = Jsoup.parse(index,"UTF-8","");
			Elements links = doc.select("a[href]");
			Pattern p = Pattern.compile("^http://www\\.wpi\\.edu/academics/facultydir/.+$");
			Matcher m = null;
			for (Element link : links) {
				String url = link.attr("href");
				m = p.matcher(url);
				if (m.matches() && (!urlList.contains(url))) urlList.add(url);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
		//set threads
		for (String url : urlList) threads.add(new Thread(new Runnable() {
			public void run() {
				htmls.add(getHTML(url));
				amount--;
			}	
		}));
		amount = threads.size();
	}
	
	public File getHTML(String url) {
		String fileName = url.substring(40);
		File html = new File(fileName);
		HttpRequest hr =HttpRequest.get(url);
		hr.receive(html);
		return html;
	}
	
	public void single() {
		long start= System.currentTimeMillis();
		for (String url : urlList) getHTML(url);
		long time = System.currentTimeMillis() - start;
		System.out.println("���߳�ִ��ʱ�䣺"+time);
	}
	
	public void multi() {
		long start = System.currentTimeMillis();
		for (Thread thread : threads) thread.start();
		while(amount>0);
		long time = System.currentTimeMillis() - start;
		System.out.println("���߳�ִ��ʱ�䣺"+time);
	}
	
	public void parse() {
		for (File html : htmls) {
			if (html.getName().equals("sms.html")) continue;
			professors.add(new Professor2014301060003(html));
		}	
	}
	
	public void database() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		try {
			String str;
			Connection con = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/new_schema","root","271314");
			PreparedStatement ps=null;
			for (Professor2014301060003 professor : professors) {
				str="insert into proinfo(name,educationBackground,researchInterests,email,phone) " + professor.getInfo();
				ps=con.prepareStatement(str);
				ps.executeUpdate(str);		
			}
			ps.close();
			con.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
