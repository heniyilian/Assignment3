import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

public class Professor2014301060003 {
	private String name;
	private String phone;
	private String email;
	private String educationBackground;
	private String researchInterests;
	
	public Professor2014301060003(File html) {
		try {
			Document doc = Jsoup.parse(html,"UTF-8","");
			//name
			Elements nameE=doc.getElementsByTag("h2");
			name = nameE.first().text();
			//phone & email
			Element contactInfo = doc.getElementById("contactinfo");
			String contactInfoStr = contactInfo.toString();
			Pattern pEmail = Pattern.compile("[\\w]+@[\\w]+\\.[a-zA-Z]+");
			Pattern pPhone = Pattern.compile("\\+((\\-)?[\\d]+)+");
			Matcher mEmail = pEmail.matcher(contactInfoStr);
			Matcher mPhone = pPhone.matcher(contactInfoStr);
			if (mEmail.find()) email = mEmail.group(0);
			if (mPhone.find()) phone = mPhone.group(0);
			//education background
			Elements title = doc.getElementsMatchingOwnText("Education");
			Element educationTitle = title.get(0);
			Element education = educationTitle.nextElementSibling();
			Elements allEducationInfo = education.getAllElements();
			educationBackground = "";
			for (Element educationInfo : allEducationInfo) {
				if (educationInfo.hasText()) {
					educationBackground += educationInfo.ownText() + "  ";
				}
			}
			//research interests
			title = doc.getElementsMatchingOwnText("Research Interests");
			researchInterests = "";
			if (title.hasText()) {
				Element researchInterestsTitle = title.get(0);
				Element researchInterestsEle = researchInterestsTitle
						.nextElementSibling();
				Elements allResearchInterests = researchInterestsEle
						.getAllElements();
				for (Element researchInterest : allResearchInterests) {
					if (researchInterest.hasText()) {
						researchInterests += researchInterest.ownText() + ",";
					}
				}
				if (!researchInterests.isEmpty())
					researchInterests = researchInterests.substring(1,researchInterests.length()-1);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public String getInfo() {
		return "values('"+name+"','"+educationBackground+"','"+researchInterests+"','"+email+"','"+phone+"');";
	}
}
