import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Main2014301060003 {

	public static void main(String[] args) {
		ProfessorList2014301060003 pl = new ProfessorList2014301060003();
		pl.single();
		pl.multi();
		pl.parse();
		pl.database();
	}
}
